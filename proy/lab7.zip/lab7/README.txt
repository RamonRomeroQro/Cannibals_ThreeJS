/**********************************************************************
 *  README.txt
 *  TC3022 - Robot
 **********************************************************************/

/**********************************************************************
* What is your name?
***********************************************************************/

Jose Ramon Romero Chavez - A01700318



/**********************************************************************
* What browser and operating system did you test your program with?
***********************************************************************/

Firefox Quantum 64.0.2 (64-bit) on macOS Mojave 10.14 (18A391)



/**********************************************************************
* Approximately how many hours did you spend working on this assignment?
***********************************************************************/

Arround 2 hours


/**********************************************************************
 * Describe any problems you encountered in this assignment.
 * What was hard, or what should we warn students about in the future?
 * How can I make this assignment better?
 **********************************************************************/

The complexity of rendering movement


/**********************************************************************
 * List any other comments (about the assignment or your submission)
 * here. Feel free to provide any feedback on what you learned from
 * doing the assignment, whether you enjoyed doing it, etc.
 **********************************************************************/

We shold do more examples in class about this kind of movement.
